$(document).ready(function () {
    $("#My").accordion();
});