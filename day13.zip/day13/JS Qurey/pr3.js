 //$(document).ready(function(){
//  $("#yo").dialog({
//     autoOpen:true,
    

//  })  
// $("my").click(function(){
//     $("yo").dialog("open");
// });
// });
$(document).ready(function(){
   $("#spinnerfun").spinner();
});