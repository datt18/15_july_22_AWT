$(document).ready(function(){
    $("#picker1").datepicker({
        showweek:true,
        yearsuffix:"(DOB)",
        showAnim:"slide"
    });

    $("#picker2").datepicker();
   
});
